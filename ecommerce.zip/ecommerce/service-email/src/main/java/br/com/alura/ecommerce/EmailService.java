package br.com.alura.ecommerce;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import java.io.IOException;
import java.util.HashMap;

public class EmailService {

    public static void main(String[] args) throws IOException {
        var emailService = new EmailService();
        try (var kafkaService = new KafkaService<>(EmailService.class.getSimpleName(),
                "ECOMMERCE_SEND_EMAIL",
                emailService::parse,
                Email.class,
                new HashMap<>())) {
            kafkaService.run();
        }
    }

    private void parse(ConsumerRecord<String, Email> record) {
        System.out.println("---------------------------------------------");
        System.out.println("--Sending email--");
        System.out.println("KEY:       " + record.key());
        System.out.println("VALUE:     " + record.value());
        System.out.println("PARTITION: " + record.partition());
        System.out.println("OFFSET:    " + record.offset());
        System.out.println("---------------------------------------------");

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Email send");
    }

}
